package model;

public class ReturnResult {
		public boolean isSuccess=false;
		
		public String failreason=null;
		
		public Object returnData=null;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
