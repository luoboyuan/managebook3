package model;

import java.util.Vector;


public class BookList extends Vector<Book>{
		  
		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}

	}